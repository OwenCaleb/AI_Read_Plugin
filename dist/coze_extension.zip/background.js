/**
 * @fileoverview 浏览器扩展的后台脚本，处理API调用
 * @author AI助手
 * @version 1.0.0
 */

/**
 * Coze工作流API配置
 * @constant {Object}
 */
const COZE_API_CONFIG = {
  url: 'https://api.coze.cn/v1/workflow/run',
  headers: {
    'Authorization': 'Bearer pat_itGi9hViZSmzrbSQuSH2h1wzU2wsro3YwkqgIiF1ONegCaVKvv7M7fmwy7Zl74Ob',
    'Content-Type': 'application/json'
  },
  workflowId: '7489832031674204211'
};

/**
 * 处理文本中的转义字符
 * @param {string} text - 需要处理的文本
 * @returns {string} 处理后的文本
 */
function unescapeText(text) {
  if (!text || typeof text !== 'string') return text;
  
  // 替换常见的转义序列
  return text
    .replace(/\\"/g, '"')     // 双引号
    .replace(/\\'/g, "'")     // 单引号
    .replace(/\\n/g, '\n')    // 换行
    .replace(/\\r/g, '\r')    // 回车
    .replace(/\\t/g, '\t')    // 制表符
    .replace(/\\\\/g, '\\');  // 反斜杠
}

/**
 * 调用Coze工作流API
 * @async
 * @param {string} articleUrl - 用户输入的URL
 * @returns {Promise<Object>} API返回的结果
 * @throws {Error} 请求失败时抛出错误
 */
async function callCozeWorkflow(articleUrl) {
  try {
    console.log('正在调用Coze工作流API...', articleUrl);
    
    // 验证URL格式
    try {
      new URL(articleUrl);
    } catch (e) {
      throw new Error('无效的URL格式，请检查输入');
    }
    
    const requestData = {
      workflow_id: COZE_API_CONFIG.workflowId,
      parameters: {
        article_url: articleUrl
      }
    };
    
    console.log('请求数据:', JSON.stringify(requestData));
    
    // 添加超时处理
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000); // 30秒超时
    
    try {
      const response = await fetch(COZE_API_CONFIG.url, {
        method: 'POST',
        headers: COZE_API_CONFIG.headers,
        body: JSON.stringify(requestData),
        signal: controller.signal
      });
      
      clearTimeout(timeoutId); // 清除超时
      
      console.log('API响应状态:', response.status);
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('HTTP错误响应:', errorText);
        throw new Error(`HTTP错误 ${response.status}: ${response.statusText}`);
      }
      
      const responseText = await response.text();
      console.log('API原始响应:', responseText.substring(0, 200) + (responseText.length > 200 ? '...' : ''));
      
      let data;
      try {
        data = JSON.parse(responseText);
      } catch (parseError) {
        console.error('JSON解析错误:', parseError);
        // 如果无法解析为JSON，直接返回原始文本
        return responseText;
      }
      
      console.log('API返回数据结构:', Object.keys(data));
      return data;
    } catch (fetchError) {
      clearTimeout(timeoutId);
      if (fetchError.name === 'AbortError') {
        throw new Error('请求超时，请稍后重试');
      }
      throw fetchError;
    }
  } catch (error) {
    console.error('API调用失败:', error);
    throw error;
  }
}

// 监听来自弹出窗口的消息
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'callCozeAPI') {
    console.log('收到API调用请求:', request.url);
    
    // 调用API并发送响应
    callCozeWorkflow(request.url)
      .then(data => {
        console.log('API调用成功，返回数据类型:', typeof data);
        sendResponse({data: data});
      })
      .catch(error => {
        console.error('发送API调用错误:', error);
        sendResponse({error: `调用Coze工作流API失败: ${error.message}`});
      });
    
    // 返回true表示将异步发送响应
    return true;
  }
}); 
